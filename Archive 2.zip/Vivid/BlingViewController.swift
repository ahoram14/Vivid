//
//  BlingViewController.swift
//  Vivid
//
//  Created by Amira Horam on 8/12/20.
//  Copyright © 2020 Amira Horam. All rights reserved.
//

import UIKit

class BlingViewController: UIViewController {

    @IBOutlet weak var xButton: UIButton!
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    let collage = [ "aestheticcollage2", "aestheticcollage3", "aestheticcollage4"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func heartButton(_ sender: Any) {
        let randomizedCollages:Int = Int(arc4random_uniform(3))
        imageView.image = UIImage (named: collage[randomizedCollages]) 
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
